Project Name: DevChristina Portfolio

 A personal portfolio website showcasing projects, skills, and contact information.


Extract the ZIP file.

Upload to a web server (or run locally with php -S localhost:8000).

Ensure PHPMailer is installed using composer require phpmailer/phpmailer.


Edit contact.php with SMTP settings.

Update links in index.html if needed.


Designed by DevChristina.



<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // PHPMailer must be installed

// Your email where messages will be sent
$receiving_email_address = 'michealmunachi94@gmail.com';

// SMTP Settings
$smtp_host = 'your_smtp_host';
$smtp_username = 'your_smtp_username';
$smtp_password = 'your_smtp_password';
$smtp_port = 587;

// Google reCAPTCHA keys
$recaptcha_secret = "your_recaptcha_secret_key";
$recaptcha_response = $_POST['g-recaptcha-response'];

// Verify reCAPTCHA
$verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$recaptcha_secret}&response={$recaptcha_response}");
$captcha_success = json_decode($verify);

if (!$captcha_success->success) {
    die("reCAPTCHA verification failed. Please try again.");
}

// Check if all fields are filled
if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['subject']) || empty($_POST['message'])) {
    die("Please fill in all required fields.");
}

// File Upload Handling
$attachment = $_FILES['attachment'] ?? null;
$upload_path = "../uploads/";

if ($attachment && $attachment['error'] == 0) {
    $filename = basename($attachment['name']);
    $target_file = $upload_path . $filename;
    move_uploaded_file($attachment['tmp_name'], $target_file);
} else {
    $target_file = null;
}

// Send Email using PHPMailer
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = $smtp_host;
    $mail->SMTPAuth = true;
    $mail->Username = $smtp_username;
    $mail->Password = $smtp_password;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = $smtp_port;

    // Sender and Recipient
    $mail->setFrom($_POST['email'], $_POST['name']);
    $mail->addAddress($receiving_email_address);

    // Attach File (if uploaded)
    if ($target_file) {
        $mail->addAttachment($target_file);
    }

    // Email Content
    $mail->isHTML(true);
    $mail->Subject = $_POST['subject'];
    $mail->Body = "<strong>Name:</strong> {$_POST['name']}<br>
                   <strong>Email:</strong> {$_POST['email']}<br>
                   <strong>Message:</strong><br>{$_POST['message']}";

    $mail->send();

    // Auto-reply to the user
    $reply_mail = new PHPMailer(true);
    $reply_mail->isSMTP();
    $reply_mail->Host = $smtp_host;
    $reply_mail->SMTPAuth = true;
    $reply_mail->Username = $smtp_username;
    $reply_mail->Password = $smtp_password;
    $reply_mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $reply_mail->Port = $smtp_port;

    $reply_mail->setFrom($receiving_email_address, "MUNAfolio");
    $reply_mail->addAddress($_POST['email']);
    $reply_mail->isHTML(true);
    $reply_mail->Subject = "Thank You for Contacting MUNAfolio!";
    $reply_mail->Body = "Hello {$_POST['name']},<br>Thank you for reaching out! We will get back to you shortly.<br><br>Best Regards,<br>MUNAfolio";

    $reply_mail->send();

    echo "Your message has been sent successfully!";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
